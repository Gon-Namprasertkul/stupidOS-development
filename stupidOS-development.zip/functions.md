# StupidOS
This is not an os!

# Passcode
The passcode is 3958

# Functions

# 1.Calculator
How to use:select an operation,select 1st number, select 2nd number

# 2.Grade Calculator
How to use:Enter your score

# 3.Random number generator
How to use:select least number,select most number

# 4.Countdown timer
How to use:select seconds to Countdown

# 5.Terminal(Pre-Alpha)
How to use:enter commands
(You can see commands with help commands)