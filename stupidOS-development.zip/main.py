#file path is 'sys.argv[0]'

__author__ = 'Gon'
__copyright__ = 'Copyright 2020-2021, StupidOS'
#modules
import time as t
import random
import os,sys


def start():
	print ('      _               _     _  ___  ____  ')
	print ('  ___| |_ _   _ _ __ (_) __| |/ _ \/ ___| ')
	print (" / __| __| | | | '_ \| |/ _` | | | \___ \ ")
	print (' \__ \ |_| |_| | |_) | | (_| | |_| |___) |')
	print (' |___/\__|\__,_| .__/|_|\__,_|\___/|____/ ')
	print ('               |_|                        ')
	print (__copyright__)



def installing():
	print('')
	def loading():
		dots = '⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜'
		for x in dots:
			print(x,end='')
			sys.stdout.flush()
			t.sleep(random.uniform(0,1))
		print('')
	t.sleep(2)
	print('installing modules')
	loading()
	print ('loading modules')
	loading()
	print('loading stupidOS')
	loading()
	print('starting stupidOS')
	loading()
	start()

installing()

def plus():
    mayplus = input('Enter your first number: ')
    plus = int(mayplus)
    mayplus1 = input('Enter your second number: ')
    plus1 = int(mayplus1)
    mayresult = plus + plus1
    result = str(mayresult)
    print (result)
    a1 = input('Enter any key to go back: ')
    if a1 == 'b' or 'B':
        cal()
    else:
        cal()

def minus():
    maylob = input('Enter your first number: ')
    lob = int(maylob)
    maylob1 = input('Enter your second number: ')
    lob1 = int(maylob1)
    mayrelob = lob - lob1
    relob = str(mayrelob)
    print (relob)
    a2 = input('Enter any key to go back: ')
    if a2 == 'b' or 'B':
        cal()
    else:
        cal()

def time():
    maytimes = input('Enter your first number: ')
    times = int(maytimes)
    maytimes1 = input('Enter your second number: ')
    times1 = int(maytimes1)
    mayretimes = times * times1
    retimes = str(mayretimes)
    print (retimes)
    a3 = input('Enter any key to go back: ')
    if a3 == 'b' or 'B':
        cal()
    else:
        cal()

def harl():
    mayhal = input('Enter your first number: ')
    hal = int(mayhal)
    mayhal1 = input('Enter your second number: ')
    hal1 = int(mayhal1)
    mayrehal = hal / hal1
    rehal = str(mayrehal)
    print (rehal)
    a4 = input('Enter any key to go back: ')
    if a4 == 'b' or 'B':
        cal()
    else:
        cal()

def cal():
    print ('Select an operation')
    print ('[1] +')
    print ('[2] -')
    print ('[3] x')
    print ('[4] /')
    print ('[5] Quit')
    notsel = input('Enter your choice: ')
    sel = int(notsel)
    if sel == 1:
        plus()
    elif sel == 2:
        minus()
    elif sel == 3:
        time()
    elif sel == 4:
        harl()
    elif sel == 5:
        mainmenu()
    else:
        print ("It's not a choice")
        bkey = input('Enter any key to go back: ')
        if bkey == 'b' or 'B':
            cal()


def gradecal():
    print ('[1] Grade 1-4')
    print ('[2] Grade A-F')
    print ('[0] Quit')
    pls = input('Please enter your choice: ')
    yea = int(pls)
    if yea == 1:
        score = input('Please enter your score: ')
        rs = int(score)
        if rs >= 80:
            print ('Grade 4')
        elif rs >= 70:
            print ('Grade 3')
        elif rs >= 60:
            print ('Grade 2')
        elif rs >= 50:
            print ('Grade 1')
        else:
            print ('Grade 0')
        goodb = input('Enter any key to go back: ')
        if goodb == 'b' or 'B':
            gradecal()
        else:
            gradecal()
    elif yea == 2:
        afscore = input('Enter your score: ')
        ras = int(afscore)
        if ras >= 90:
            print ('Grade A')
        elif ras >= 85:
            print ('Grade B+')
        elif ras >= 80:
            print ('Grade B')
        elif ras >= 75:
            print ('Grade C+')
        elif ras >= 70:
            print ('Grade C')
        elif ras >= 65:
            print ('Grade D+')
        elif ras >= 60:
            print ('Grade D')
        else:
            print ('Grade F')
        yeeyee = input('Enter any key to go back: ')
        if yeeyee == 'b' or 'B':
            gradecal()
        else:
            gradecal()
    elif yea == 0:
        mainmenu()
    else:
        print ("It's not a choice")
        gradecal()



def rand():
    least = input('Please enter the least number: ')
    most = input('Please enter the most number: ')
    result = random.randint(int(least), int(most))
    print ('the number is ' + str(result))
    why_b = input('Enter any key to go back: ')
    if why_b == 'b' or 'B':
        mainmenu()
    else:
        mainmenu()

def credit():
    print ('----------------------------------------------')
    print ('')
    print ('version 2.0.1 Development')
    print ('scripted by Gon(ForesterBlox)')
    print ('language used:Python')
    print ('ascii powered by Mr.bot')
    print ('Mr.bot made by S3CR3T DEV')
    print ('Mr.bot link: https://discord.com/oauth2/authorize?client_id=853828059106377729&permissions=8&scope=bot')
    print ('Python link: https://python.org')
    print ('Support server: https://discord.io/TechNoGuys')
    print ('')
    print ('----------------------------------------------')
    goback = input('Enter any key to go back: ')
    if goback == 'b':
        mainmenu()
    else:
        mainmenu()


def cdtm():
    seconds = int(input('How many seconds to countdown: '))
    for i in range(seconds):
        print(str(seconds - i) + 'seconds left')
        t.sleep(1)
    bak = input('Enter any key to go back: ')
    if bak == 'b':
        mainmenu()
    else:
        mainmenu()







def cmd():
    while 3>2:
        cmdline = input('Please enter a command: ')
        if cmdline == 'help':
            print ('---------------------------------------------------')
            print ('')
            print ('List of commands:')
            print ('1.Help (this command)')
            print ('2.exit() is a command to quit terminal')
            print ('3.shutdown is a command for shutting down the stupidOS')
            print ('4.sudo is a sudo command')
            print ('')
            print ('---------------------------------------------------')
            sudo = input()
        elif cmdline == 'exit()':
            mainmenu()
        elif cmdline == 'shutdown':
            quit()
        elif cmdline == 'sudo':
            sudo = input('Please enter a sudo command: ')
            if sudo == '-h':
                print ('---------------------------------------------------')
                print ('')
                print ('ABOUT SUDO')
                print ('sudo is a command for admin')
                print ('you can use sudo command to use admin commands')
                print ('LIST OF COMMANDS')
                print ('1.-h (this command)')
                print ('2.-k is a command to uninstall stupidOS')
                print ('3.-o is a command to open a file')
                print ('')
                print ('---------------------------------------------------')
            elif sudo == '-k':
                yorno = input('Are you sure you want to kill stupidOS?(y/n): ')
                if yorno == 'y':
                    os.remove(sys.argv[0])
                elif yorno == 'n':
                    cmd()
            elif sudo == '-o':
                findfile = input('Please enter a file path')
                os.startfile(findfile)

        else:
            print('command not found')









def mainmenu():
    print ('Welcome to stupidOS')
    print ('[1] Calculator')
    print ('[2] Grade calculator')
    print ('[3] Random number generator')
    print ('[4] Countdown timer')
    print ('[5] Terminal')
    print ('[6] Credit')
    print ('[0] Quit')
    option = input('Enter your choice: ')
    choice = int(option)
    if choice == 1:
        cal()
    elif choice == 2:
        gradecal()
    elif choice == 0:
        print ('Thank you for using!')
        print ('Closing..')
        quit()
    elif choice == 3:
        rand()
    elif choice == 4:
        cdtm()
    elif choice == 5:
        cmd()
    elif choice == 6:
        credit()
    else:
        print ("It's not a choice!")
        supab = input('Enter any key to go back')
        if supab == 'B' or 'b':
            mainmenu()
        else:
            mainmenu()

heyhey = input('Enter the passcode: ')
heyhey1 = int(heyhey)
if heyhey1 == (3958):
    mainmenu()
else:
    print ('Invalid passcode closing...')
    exit()




#this is development version


mainmenu()